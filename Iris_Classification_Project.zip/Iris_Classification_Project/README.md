# Iris Flower Classification

A complete machine-learning classification pipeline using the built-in Iris dataset and Logistic Regression.

## Project steps

1. Load the Iris dataset from scikit-learn.
2. Standardize the input features with `StandardScaler`.
3. Split the data into training and testing sets (80% / 20%).
4. Train a Logistic Regression classifier.
5. Print accuracy, a classification report, and a confusion matrix.

## Setup

Python 3.9 or newer is recommended.

```bash
# (Optional) Create and activate a virtual environment
python -m venv .venv

# Windows
.venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Run

```bash
python main.py
```

The program prints the model accuracy and evaluation metrics in the terminal.

## Dataset

The Iris dataset contains 150 samples from three flower species:
- Setosa
- Versicolor
- Virginica

The four input features are sepal length, sepal width, petal length, and petal width.
